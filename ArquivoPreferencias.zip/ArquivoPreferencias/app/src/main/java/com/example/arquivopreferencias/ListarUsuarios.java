package com.example.arquivopreferencias;

import android.app.ListActivity;
import android.os.Bundle;

import java.util.List;

public class ListarUsuarios extends ListActivity {

protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.usuarios);

    BancoDeDados bancoDeDados = new BancoDeDados(this);

    List<Usuario> list = bancoDeDados.buscar();
    setListAdapter(new UsuarioAdapter(this,list));
}
}
