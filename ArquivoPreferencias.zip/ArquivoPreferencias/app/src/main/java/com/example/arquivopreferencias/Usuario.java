package com.example.arquivopreferencias;

public class Usuario {
private String nome;
private String email;
private String senha;
private long id;

public String getNome(){return  nome;}

public void setNome(String novoNome){this.nome = novoNome;}

public String getEmail(){return  nome;}

public void setEmail(String novoEmail){this.nome = novoEmail;}

public String getSenha(){return  nome;}

public void setSenha(String novaSenha){this.nome = novaSenha;}

public long getId(){return id;}

public void setId(long novoId){this.id = novoId;}
}
