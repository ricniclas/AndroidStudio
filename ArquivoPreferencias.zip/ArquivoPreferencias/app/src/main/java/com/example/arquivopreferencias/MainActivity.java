package com.example.arquivopreferencias;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewDebug;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Preferencias preferencias = new Preferencias();

        final EditText nome = (EditText) findViewById(R.id.inputName);
        final EditText email = (EditText) findViewById(R.id.inputEmail);
        final EditText salario = (EditText) findViewById(R.id.inputSalario);
        String stringAuxiliar = "";

        Button gravar = (Button) findViewById(R.id.btnGravar);
        gravar.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v)
            {

                boolean resultado1 = preferencias.SaveOneInfo(v.getContext(),"nome",nome.getText().toString());
                boolean resultado2 = preferencias.SaveOneInfo(v.getContext(),"email",email.getText().toString());
                boolean resultado3 = preferencias.SaveOneInfo(v.getContext(),"salario",Integer.parseInt(salario.getText().toString()));

                if(resultado1 && resultado2 && resultado3)
                {
                    Toast.makeText(getBaseContext(),"Gravado com sucesso",Toast.LENGTH_SHORT).show();
                }
                else
                    {
                        Toast.makeText(getBaseContext(),"Algo deu errado",Toast.LENGTH_SHORT).show();
                    }
            }
        });

        Button limpar = (Button) findViewById(R.id.btnLimpar);
        limpar.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view)
            {
                nome.setText("");
                email.setText("");
                salario.setText("");
            }

        });

        Button recuperar = (Button) findViewById(R.id.btnRecuperar);
        recuperar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                //SharedPreferences prefs = getSharedPreferences("preferencias", Context.MODE_PRIVATE);
                nome.setText(preferencias.SendStringBack(v.getContext(),"nome"));
                email.setText(preferencias.SendStringBack(v.getContext(),"email"));
                salario.setText(String.valueOf(preferencias.SendIntBack(v.getContext(),"salario")));

            }
        });
    }
}