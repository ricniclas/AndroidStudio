package com.example.arquivopreferencias;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.net.FileNameMap;
import java.util.List;

public class UsuarioAdapter extends BaseAdapter {
    private Context context;
    private List<Usuario> list;

    public UsuarioAdapter(Context context, List<Usuario> list){
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
    final int auxPosition = position;
    LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
    final LinearLayout layout = (LinearLayout)inflater.inflate(R.layout.usuarios,null);

        TextView tvNome = layout.findViewById(R.id.nomeList);
        tvNome.setText(list.get(position).getNome());

        Button btnEditar = layout.findViewById(R.id.btnEditarList);
        btnEditar.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                BancoDeDados bancoDeDados = new BancoDeDados(context);
                bancoDeDados.deletar(list.get(auxPosition));

                layout.setVisibility(view.GONE);
            }});

    return layout;
    }
}
